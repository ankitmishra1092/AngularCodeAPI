export class RegisterDTO{
    Id: string;  
    fullName: string;  
    email: string;
    phone: string;  
}