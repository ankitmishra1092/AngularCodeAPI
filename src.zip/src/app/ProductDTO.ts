export class ProductDTO{
    ID: string;  
    Name: string;  
    Price: string;  
}