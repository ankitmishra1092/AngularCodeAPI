import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductComponent} from '../app/product/product.component';
import {LoginComponent} from '../app/login/login.component';
import { RegisterComponent } from './register/register.component';
const routes: Routes = [
  {path: '', redirectTo: '/Product', pathMatch: 'full'},
   {path: 'Product', component: ProductComponent},
   {path: 'Login', component: LoginComponent},
   {path: 'Register', component: RegisterComponent}
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
