import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { RegisterDTO } from '../app/RegisterDTO';
import { Observable } from 'rxjs';
@Injectable({
    providedIn: 'root'
  })

  export class RegisterService {
    ApiUrl = 'http://localhost:57046/';
    constructor(private httpclient: HttpClient) { }
    
    Register(register: RegisterDTO){
        return this.httpclient.post<RegisterDTO>(this.ApiUrl+'Api/Product/Register',register);
      }
      
    GetRegisteredUsers():Observable<RegisterDTO[]>{
        return this.httpclient.get<RegisterDTO[]>(this.ApiUrl+'Api/Product/GetRegister');
    }  
    
    UserAuthentication(UserName: string,Password: string):Observable<any>{
            let credentials='username=' +UserName  + '&password=' +Password +'&grant_type=password'; 
            var reqHeader = new HttpHeaders({'Content-Type': 'application/x-www-urlencoded','No-Auth':'True' });
           return this.httpclient.post<any>(this.ApiUrl+'token',encodeURI(credentials),{headers:reqHeader});
    }
    
  }