import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { ConfirmEqualValidatorDirective } from './confirm-equal-validator.directive';
import { RegisterService } from '../register.service';
import { RegisterDTO } from '../RegisterDTO';
import { Router} from '@angular/router';
declare var NgForm: any;
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private registerservice: RegisterService, private router: Router) { }

  // constructor(private formBuilder: FormBuilder) { }
  title = 'Reactive-form-validation-in-angular 8/9';

  RegisterList: RegisterDTO[];

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
    fullName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', Validators.required],
    password: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', Validators.required],
    tnc: ['', Validators.required]
   });

    this.GetAllRegisteredUsers();
 }

 get fval() {
  return this.registerForm.controls;
  }
  // this.user.fullName='';
  signup(){
            this.submitted = true;
            if (this.registerForm.invalid) {
            return;
            }
            const register = this.registerForm.value;
            this.RegisterUser(register);
            // alert('form fields are validated successfully!');
 }
  RegisterUser(register: RegisterDTO){
    this.registerservice.Register(register).subscribe(() => {
     // data=>{this.RegisterList=data;
     this.GetAllRegisteredUsers();
    });
 }

 GetAllRegisteredUsers(){
       this.registerservice.GetRegisteredUsers().subscribe(data => { this.RegisterList = data; });
}

}
