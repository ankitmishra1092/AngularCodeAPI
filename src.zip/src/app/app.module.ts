import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AlertModule} from './_alert';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ProductComponent } from './product/product.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ProductService } from './product.service';
import { AuthInterceptor } from '../app/auth.interceptor';
import {enableProdMode} from '@angular/core';
import { RegisterComponent } from './register/register.component';
// import { ConfirmEqualValidatorDirective } from './confirm-equal-validator.directive';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ProductComponent,
    RegisterComponent // ,
    // ConfirmEqualValidatorDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    AlertModule,
    FormsModule
  ],
  providers: [
    ProductService,
  {
   provide: HTTP_INTERCEPTORS,
   useClass: AuthInterceptor,
   multi: true
  }    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
