import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ProductDTO } from '../ProductDTO';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AlertService } from '../_alert';
import random from '@angular-devkit/schematics/src/rules/random';
import { Router} from '@angular/router';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  public options = {
      autoClose: false,
      keepAfterRouteChange: false
  };

  constructor(private productservice: ProductService, private router: Router, public alertService: AlertService) { }
  // tslint:disable-next-line: member-ordering
  ProductList: ProductDTO[];
  // tslint:disable-next-line: member-ordering
  CovidInfo: any;
  // tslint:disable-next-line: member-ordering
  product: ProductDTO;
  // tslint:disable-next-line: member-ordering
  productIdUpdate = null;
  ProductForm = new FormGroup ({
    ID: new FormControl('', Validators.required) ,
    Name: new FormControl('', Validators.required),
    Price: new FormControl(''),
   });

  ngOnInit() {

   if ( window.sessionStorage.getItem('userToken') == null) {
      this.router.navigate(['/Login']);
    }
   this.GetAllProducts();
  // this. GetCovidInfo();
  }
   OnSubmit(){
    if (this.productIdUpdate == null){
       const product = this.ProductForm.value;
       this.InsertProduct(product);
    }
    else{
       const employee = this.ProductForm.value;
       this.UpdateProduct(employee);
    }
 }

 GetCovidInfo()
 {

   this.productservice.GetCovidInfo().subscribe(data => {this.CovidInfo = data; });
 }

 GetAllProducts(){

    this.productservice.GetProducts().subscribe(data => {this.ProductList = data; });
 }
 GetProductById(Id: string){
    this.productservice.GetProductById(Id).subscribe(data => {
       this.SetProductFormValues(data);
    });

 }
 SetProductFormValues(product: ProductDTO){
   // this.ProductForm.controls['ID'].setValue(product.ID);
   this.ProductForm.controls.ID.setValue(product.ID);
   // tslint:disable-next-line: no-unused-expression
   this.ProductForm.controls.ID.disabled;
   //  this.ProductForm.controls['Name'].setValue(product.Name);
   this.ProductForm.controls.Name.setValue(product.Name);
   this.ProductForm.controls.Price.setValue(product.Price);
   this.productIdUpdate = product.ID;
 }
 InsertProduct(product: ProductDTO){
    this.productservice.InsertProduct(product).subscribe(() => {
       this.GetAllProducts();
    });
 }
 UpdateProduct(product: ProductDTO){
   product.ID = this.productIdUpdate;
   this.productservice.UpdateProduct(product).subscribe(() => {
    this.productIdUpdate = null;
    this.GetAllProducts();
  });
 }
 DeleteProduct(Id: string){
  this.productservice.DeleteProduct(Id).subscribe(() => {
    this.productIdUpdate = null;
    this.GetAllProducts();
  });
 }

}
