﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI_Oauth.Models;

namespace WebAPI_Oauth.Controllers
{
        [RoutePrefix("Api/Product")]//This is Route prefix filter which will be added in the url for this specfic controller
        [Authorize]//This filter redirect the request to the provider class first request will authenticate if authentication sucessful than it will come to here
        public class ProductController : ApiController
        {
            [HttpGet]
            [Route("GetProducts")]
            public List<Product> GetProducts()//This is th get method which get all the products from the db and return
            {
            List<Product> productList = new List<Product>();
            using (WebApiDBEntities WebApiDBEntities=new WebApiDBEntities())
            {
                productList = WebApiDBEntities.Products.ToList();
            }
            return productList;
            }
            [HttpGet]
            [Route("GetProductById/{Id}")]
            public Product GetProductById(string Id)//This is th get method which get one record on the basis of ID 
            {
                Product product = new Product();
                using (WebApiDBEntities WebApiDBEntities = new WebApiDBEntities())
            {
                product = WebApiDBEntities.Products.Find(Convert.ToInt32(Id));
            }              
                return (product);
            }
            [HttpPost]
            [Route("InsertProduct")]
            public IHttpActionResult Create(Product product)//This method will insert the product into db
            {
            using (WebApiDBEntities WebApiDBEntities = new WebApiDBEntities())
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                else
                {
                    WebApiDBEntities.Products.Add(product);
                    WebApiDBEntities.SaveChanges();
                    return Ok(product);
                }
            }               
            }
            [HttpPut]
            [Route("UpdateProduct")]
            public IHttpActionResult Update(Product product)//Update method will update the product
            {
            using (WebApiDBEntities WebApiDBEntities = new WebApiDBEntities())
            {
                if (ModelState.IsValid)
                {
                    WebApiDBEntities.Entry(product).State = System.Data.Entity.EntityState.Modified;
                    WebApiDBEntities.SaveChanges();
                    return Ok(product);
                }
                else
                {
                    return BadRequest(ModelState);
                }
            }                      
            }
            [HttpDelete]
            [Route("DeleteProduct/{Id}")]
            public IHttpActionResult Delete(int Id)//this method will Delete the record
            {
            using (WebApiDBEntities WebApiDBEntities = new WebApiDBEntities())
            {
                Product product = WebApiDBEntities.Products.Find(Convert.ToInt32(Id));
                if (product == null) { return NotFound(); }
                else
                {
                    WebApiDBEntities.Products.Remove(product);
                    WebApiDBEntities.SaveChanges();
                    return Ok(product);
                }
            }                         
            }



        [HttpGet]
        [Route("GetRegister")]
        public List<tbl_register> GetRegister()//This is th get method which get all the products from the db and return
        {
            List<tbl_register> registerList = new List<tbl_register>();
            using (WebApiDBEntities WebApiDBEntities = new WebApiDBEntities())
            {
                registerList = WebApiDBEntities.tbl_register.ToList();
            }
            return registerList;
        }

        [HttpPost]
        [Route("Register")] //Issue Book
        public IHttpActionResult Create(tbl_register register)//This method will insert the product into db
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            else
            {
                using (WebApiDBEntities WebApiDBEntities = new WebApiDBEntities())
                {
                    var fullNameParam = new SqlParameter("@fulName", register.fullName);
                    var emailParam = new SqlParameter("@email", register.email);
                    var phoneParam = new SqlParameter("@phone", register.phone);
                    var passwordParam = new SqlParameter("@password", register.password);
                    /* var msgparam = new SqlParameter
                     {
                         ParameterName = "@Msg",
                         DbType = DbType.String,
                         Size = 30,
                         Direction = System.Data.ParameterDirection.Output
                     }; */
                    var result = WebApiDBEntities.Database
                        .SqlQuery<tbl_register>("sp_Register @fulName,@email,@phone,@password", fullNameParam, emailParam, phoneParam, passwordParam)
                        .ToList();

                    //string Status = msgparam.Value.ToString();
                    return Ok(result);
                }
            }
        }
    }
}
